-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: k5d204.p.ssafy.io    Database: addssafy
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `introduce` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ppt` varchar(255) DEFAULT NULL,
  `prize` bit(1) DEFAULT NULL,
  `type` int DEFAULT NULL,
  `webex_link` varchar(255) DEFAULT NULL,
  `mm_channel` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES (1,'팀 소개입니다.0','1조','1조.ppt',NULL,0,NULL,NULL),(2,'팀 소개입니다.1','2조','2조.ppt',NULL,0,NULL,NULL),(3,'팀 소개입니다.2','히사이시 조','히사이시 조.ppt',NULL,0,NULL,NULL),(4,'팀 소개입니다.3','어둠의 싸피단','어둠의 싸피단.ppt',NULL,0,NULL,NULL),(5,'팀 소개입니다.4','그만해 이러다 다죽어','그만해 이러다 다죽어.ppt',NULL,0,NULL,NULL),(6,'팀 소개입니다.5','취준팀','취준팀.ppt',NULL,0,NULL,NULL),(8,'hi','22스트팀',NULL,NULL,1,'123',NULL),(9,'testUpdateIntroduce',NULL,NULL,NULL,NULL,'testUpdateWebex',NULL),(39,'test','test',NULL,NULL,1,'test','btfzjtobn3fbukggtnprz5crmr'),(57,'hi','22스트팀','/image/597ca83c-1191-49b0-b862-ccd14098cb06.ppt',NULL,2,'123',NULL),(81,'ALZALAL','1팀입니다',NULL,NULL,0,'','kreexwzgbtg3bjmqio3gt663nc'),(92,'WEB RTC 만드실 분?','WEB RTC팀','/image/9282dfd5-6349-4e92-8598-c01f0c50f4fd.pptx',NULL,0,'https://ssafyclass.webex.com/join/jonghan1983','o4ydfdc9bffepkoocsdkueg87w'),(97,'테스트','테스트','/image/f8dd7801-7015-49b3-ac3e-51d12716994e.pptx',NULL,0,'테스트','bayp8fnpwiy5bnm1jnetor5n5r');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:35:23
