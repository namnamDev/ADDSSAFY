-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: k5d204.p.ssafy.io    Database: addssafy
-- ------------------------------------------------------
-- Server version	8.0.27-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hash_tag`
--

DROP TABLE IF EXISTS `hash_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hash_tag` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hashtag_props` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hash_tag`
--

LOCK TABLES `hash_tag` WRITE;
/*!40000 ALTER TABLE `hash_tag` DISABLE KEYS */;
INSERT INTO `hash_tag` VALUES (1,'BE','Spring'),(2,'BE','Django'),(3,'BE','OracleDB'),(4,'BE','MySQL'),(5,'BE','MariaDB'),(6,'BE','JPA'),(7,'BE','QueryDSL'),(8,'BE','Mybatis'),(9,'BE','STS'),(10,'BE','Intellij'),(11,'FE','Vue'),(12,'FE','React'),(13,'FE','TypeScript'),(14,'FE','Angular'),(15,'FE','JavaScript'),(16,'FE','Node.Js'),(17,'DEVOPS','Jenkins'),(18,'DEVOPS','Docker'),(19,'DEVOPS','AWS'),(20,'DEVOPS','Firebase'),(21,'FOUR','AI'),(22,'FOUR','BigData'),(23,'FOUR','BlockChain'),(24,'FOUR','IOT'),(25,'ETC','UCC'),(26,'ETC','PPT'),(27,'ETC','Presentation'),(28,'ETC','9 to 6'),(29,'ETC','취업 위주'),(30,'ETC','프로젝트 위주'),(31,'BADBADGE','무단결석 1회'),(32,'BADBADGE','무단결석 2회'),(33,'BADBADGE','지각으로 결석한사람'),(34,'GOODBADGE','과목평가 70점 이상'),(35,'GOODBADGE','과목평가 80점 이상'),(36,'GOODBADGE','과목평가 90점 이상'),(37,'GOODBADGE','과목평가 95점 이상'),(38,'GOODBADGE','월말평가 70점 이상'),(39,'GOODBADGE','월말평가 80점 이상'),(40,'GOODBADGE','월말평가 90점 이상'),(41,'GOODBADGE','월말평가 95점 이상'),(42,'GOODBADGE','반장 했던 교육생'),(43,'GOODBADGE','부반장 했던 교육생'),(44,'GOODBADGE','CA였던 교육생'),(45,'GOODBADGE','팀장이였던 교육생');
/*!40000 ALTER TABLE `hash_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-19  9:35:22
